

public class Cart {
	public static final int MAX_NUMBERS_ORDERED = 20;
	private DigitalVideoDisc itemsOrdered[] = new DigitalVideoDisc[MAX_NUMBERS_ORDERED];
	private int qtyOrdered = 0; 
	
	//add 1 disc to the cart- Nguyen Ngoc Kien
	public void addDigitalVideoDisc(DigitalVideoDisc disc) {
		if(qtyOrdered != 20) {
			itemsOrdered[qtyOrdered] = disc;
			qtyOrdered++;
			System.out.println("The disc has been added");
		}
		else {
			System.out.println("The cart is almost full");
		}
	}
	//add 2 disc to the cart- Nguyen Ngoc Kien
	public void addDigitalVideoDisc(DigitalVideoDisc disc1,DigitalVideoDisc disc2) {
		if(qtyOrdered + 2 < MAX_NUMBERS_ORDERED) {
			itemsOrdered[qtyOrdered] = disc1;
			qtyOrdered++;
			itemsOrdered[qtyOrdered] = disc2;
			qtyOrdered++;
			System.out.println("Two disc has been added");
		}
		else {
			System.out.println("The cart is almost full");
		}
	}
	public void removeDigitalVideoDisc(DigitalVideoDisc disc) {
		for(int i = 0; i < qtyOrdered; i++) {
			if(itemsOrdered[i].getTitle() == disc.getTitle()) {
				for(int j = i; j < qtyOrdered; j++) {
					itemsOrdered[j] = itemsOrdered[j + 1];
				}
				i--;
				qtyOrdered--;
				System.out.println("The disc has been removed");
			}
		}
	}
	public float totalCost() {
		float total = 0;
		for(int i = 0; i < qtyOrdered; i++) {
			total += itemsOrdered[i].getCost();
		}
		return total;
	}
//Tim dvd theo title	
	public DigitalVideoDisc findDigitalVideoDiscByTitle(String title) {
	    for (int i = 0; i < qtyOrdered; i++) {
	        if (itemsOrdered[i].getTitle().equals(title)) {
	            return itemsOrdered[i];
	        }
	    }
	    return null;
	    
	}
//Tim dvd theo id
	public DigitalVideoDisc findDigitalVideoDiscById(int id) {
	    for (int i = 0; i < qtyOrdered; i++) {
	        if (itemsOrdered[i].getId() == id) {
	            return itemsOrdered[i];
	        }
	    }
	    return null;
	}
		
}



