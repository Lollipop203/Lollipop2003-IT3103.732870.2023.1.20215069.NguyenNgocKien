public class Store {
    private DigitalVideoDisc[] itemsInStore;
    private int numberDVD;

    public Store() {
        itemsInStore = new DigitalVideoDisc[20];
        numberDVD = 0;
    }

    public void addDVD(DigitalVideoDisc disc) {
        if (numberDVD < 20) {
            itemsInStore[numberDVD] = disc;
            numberDVD++;
            System.out.println("The disc has been added");
        } else {
            System.out.println("The store is full");
        }
    }

    public boolean removeDVD(DigitalVideoDisc disc) {
        for (int i = 0; i < numberDVD; i++) {
            if (itemsInStore[i].equals(disc)) {
                for (int j = i; j < numberDVD - 1; j++) {
                    itemsInStore[j] = itemsInStore[j + 1];
                }
                numberDVD--;
                System.out.println("The disc has been removed");
                return true;
            }
        }
        System.out.println("The disc was not found");
        return false;
    }

    public void printDVDInStore() {
        System.out.println("DVDs in store:");
        for (int i = 0; i < numberDVD; i++) {
            System.out.println(itemsInStore[i].toString());
        }
    }

	 
}
