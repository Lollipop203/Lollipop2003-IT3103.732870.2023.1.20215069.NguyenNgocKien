public class Aims {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cart anOrder = new Cart();
		
		DigitalVideoDisc dvd1 = new DigitalVideoDisc(1,"The Lion King", "Animation", "Roger Allers", 87, 27.95f);
		
	    DigitalVideoDisc dvd2 = new DigitalVideoDisc(2,"Star Wars", "Science Fiction", "George Lucas", 87, 29.25f);
		
		anOrder.addDigitalVideoDisc(dvd1,dvd2);
		System.out.println(dvd1.toString());
		System.out.println(dvd2.toString());
		DigitalVideoDisc dvd = anOrder.findDigitalVideoDiscByTitle("The Lion King");
	    if (dvd != null) {
	        System.out.println("DVD found: " + dvd.getTitle());
	    } else {
	        System.out.println("DVD not found");
	    }
	    DigitalVideoDisc dvd3 = anOrder.findDigitalVideoDiscById(2);
	    if (dvd3 != null) {
	        System.out.println("DVD found: " + dvd3.getTitle());
	    } else {
	        System.out.println("DVD not found");
	    }
		
		
		
		
	
		
	}

}	