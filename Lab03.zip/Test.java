// Nguyen Ngoc Kien -20215069
public class Test{

    public static void main(String[] args) {
        DigitalVideoDisc ChovyDVD = new DigitalVideoDisc("Chovy");
        DigitalVideoDisc FakerDVD = new DigitalVideoDisc("Faker");
        
        
        swap(ChovyDVD, FakerDVD);
        System.out.println("Chovy dvd title: " + ChovyDVD.getTitle());
        System.out.println("Faker dvd title: " + FakerDVD.getTitle());
        
        changeTitle(ChovyDVD, FakerDVD.getTitle());
        System.out.println("Chovy dvd title: " + ChovyDVD.getTitle());
    }
    
    public static void swap(DigitalVideoDisc o1, DigitalVideoDisc o2) {
        DigitalVideoDisc temp = o1;
        o1 = o2;
        o2 = temp;
    }
    
    public static void changeTitle(DigitalVideoDisc dvd, String title) {
        String Tilte = dvd.getTitle();
        dvd.setTitle(title);
        dvd = new DigitalVideoDisc(Tilte);
    }

}
